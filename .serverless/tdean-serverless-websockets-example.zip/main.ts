const crypto = require("crypto");
const dynamodb = require("@aws-sdk/client-dynamodb");

var WebSocketClient = require('websocket').client;

const requestId = crypto.randomUUID();

var wsc = new WebSocketClient(`wss://2izayxe4sh.execute-api.eu-west-1.amazonaws.com/test?requestId=${requestId}`);

const dynamoClient = new dynamodb.DynamoDBClient({ region: "eu-west-1"});

const main = async (requestId) => {
    for (var i = 0; i <= 10; i++){
        const randomInt = crypto.randomInt(200);
        const product = {productCode: randomInt, blah:"blah"}
        await sleep(crypto.randomInt(2000));
        const input = {
            TableName: "ConnectionsTable",
            Key: {
                requestId: {S: requestId}
            },
            UpdateExpression: `SET products.#productCode = :product`,
            ExpressionAttributeNames: {
                "#productCode": randomInt.toString()
            },
            ExpressionAttributeValues: {
                ":product": {S: JSON.stringify(product)}
            }
        };
        try {
            console.log("DynamoDB Update Input", input);
            await dynamoClient.send(new dynamodb.UpdateItemCommand(input))
            console.log("Updated", input)
        } catch (err){
            console.error("DynamoDB Error", err);
            break;
        }
    }
}

function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
}

wsc.on('connectFailed', (err) => {
    console.error("WebSocket Client Failed to Connect", err);
});

wsc.on('connect', async (connection) => {
    console.log("WebSocket Client Connected");
    //console.log(connection);
    connection.on('error', function(error) {
        console.log("Connection Error: " + error.toString());
    });
    connection.on('close', function() {
        console.log('echo-protocol Connection Closed');
    });
    connection.on('message', function(message) {
        console.log("Received: '" + message.utf8Data + "'");
    });

    await main(requestId);
});

wsc.connect(`wss://2izayxe4sh.execute-api.eu-west-1.amazonaws.com/test?requestId=${requestId}`);